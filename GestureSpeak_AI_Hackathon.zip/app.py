"""
GestureSpeak AI — hackathon-ready local gesture-to-speech prototype.

Controls:
  SPACE     Add current stable gesture to the message
  A         Toggle auto-add (one phrase per stable gesture, with cooldown)
  BACKSPACE Undo last phrase
  C         Clear message
  S         Speak message (requires pyttsx3)
  Q or ESC  Quit

Scope: a small-vocabulary generic gesture recognizer, NOT a sign-language translator.
"""
from collections import Counter, deque
import time

import cv2
import mediapipe as mp

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

from gestures import classify_gesture, GESTURE_MESSAGES

WINDOW_NAME = "GestureSpeak AI | Hackathon Edition"
AUTO_ADD_COOLDOWN_SECONDS = 1.4
HISTORY_SIZE = 7
MIN_STABLE_VOTES = 4


def speak_text(text: str) -> None:
    """Speak text locally when pyttsx3 is available."""
    if not text.strip():
        return
    if pyttsx3 is None:
        print("Text-to-speech is not installed. Run: pip install pyttsx3")
        return
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
        engine.stop()
    except Exception as exc:
        print(f"Speech could not be played: {exc}")


def draw_panel(frame, gesture, message_parts, fps, auto_add, stable_votes):
    """Draw status, stability, message, and accessible keyboard guidance."""
    h, w = frame.shape[:2]
    panel_h = min(178, max(145, h // 3))
    panel_top = h - panel_h
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, panel_top), (w, h), (18, 24, 38), -1)
    cv2.addWeighted(overlay, 0.88, frame, 0.12, 0, frame)

    label = gesture or "No stable gesture"
    meaning = GESTURE_MESSAGES.get(gesture, "Hold one hand clearly in view")
    mode = "ON" if auto_add else "OFF"
    lines = [
        (f"GESTURE: {label}", (90, 230, 180), 0.68),
        (f"MEANING: {meaning}", (245, 245, 245), 0.53),
        (f"STABILITY: {stable_votes}/{HISTORY_SIZE} frames   |   AUTO-ADD: {mode}",
         (120, 205, 255), 0.48),
    ]
    y = panel_top + 27
    for text, color, scale in lines:
        cv2.putText(frame, text, (16, y), cv2.FONT_HERSHEY_SIMPLEX,
                    scale, color, 1 if scale < 0.6 else 2, cv2.LINE_AA)
        y += 27

    message = " ".join(message_parts).strip() or "(message appears here)"
    max_chars = max(25, int((w - 32) / 9))
    if len(message) > max_chars:
        message = "..." + message[-(max_chars - 3):]
    cv2.putText(frame, f"MESSAGE: {message}", (16, panel_top + 108),
                cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 220, 120), 1, cv2.LINE_AA)
    cv2.putText(frame, "SPACE add | A auto-add | S speak | BACKSPACE undo | C clear | Q quit",
                (16, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.40,
                (220, 225, 235), 1, cv2.LINE_AA)
    cv2.putText(frame, f"{fps:.0f} FPS", (w - 90, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)


def open_camera():
    """Try platform-preferred capture first, then fall back to the default backend."""
    camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not camera.isOpened():
        camera.release()
        camera = cv2.VideoCapture(0)
    if camera.isOpened():
        camera.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
        camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
        camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    return camera


def main():
    mp_hands = mp.solutions.hands
    mp_draw = mp.solutions.drawing_utils
    mp_styles = mp.solutions.drawing_styles
    camera = open_camera()

    if not camera.isOpened():
        camera.release()
        print("ERROR: Could not open webcam. Check camera permissions and close other apps using it.")
        return

    message_parts = []
    recent_predictions = deque(maxlen=HISTORY_SIZE)
    previous_time = time.time()
    fps = 0.0
    auto_add = False
    last_auto_add = 0.0
    last_auto_gesture = None

    print("GestureSpeak AI — Hackathon Edition")
    print("SPACE add | A toggle auto-add | S speak | BACKSPACE undo | C clear | Q quit")
    print("Privacy: frames are processed locally and are not uploaded by this application.")

    try:
        with mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            model_complexity=1,
            min_detection_confidence=0.62,
            min_tracking_confidence=0.58,
        ) as hands:
            while True:
                ok, frame = camera.read()
                if not ok:
                    print("Could not read a frame from the webcam.")
                    break

                frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                rgb.flags.writeable = False
                result = hands.process(rgb)
                rgb.flags.writeable = True

                raw_gesture = None
                if result.multi_hand_landmarks:
                    hand_landmarks = result.multi_hand_landmarks[0]
                    mp_draw.draw_landmarks(
                        frame, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                        mp_styles.get_default_hand_landmarks_style(),
                        mp_styles.get_default_hand_connections_style(),
                    )
                    raw_gesture = classify_gesture(hand_landmarks.landmark)

                recent_predictions.append(raw_gesture)
                counts = Counter(g for g in recent_predictions if g is not None)
                stable_gesture = None
                stable_votes = 0
                if counts:
                    candidate, votes = counts.most_common(1)[0]
                    if votes >= MIN_STABLE_VOTES:
                        stable_gesture, stable_votes = candidate, votes

                now = time.time()
                elapsed = now - previous_time
                if elapsed > 0:
                    instant_fps = 1.0 / elapsed
                    fps = instant_fps if fps == 0 else 0.85 * fps + 0.15 * instant_fps
                previous_time = now

                # Auto-add once per gesture hold; a different gesture can trigger immediately
                # after the cooldown, avoiding repeated phrase spam from a held hand.
                if auto_add and stable_gesture:
                    changed_gesture = stable_gesture != last_auto_gesture
                    cooldown_passed = now - last_auto_add >= AUTO_ADD_COOLDOWN_SECONDS
                    if changed_gesture and cooldown_passed:
                        message_parts.append(GESTURE_MESSAGES[stable_gesture])
                        last_auto_add = now
                        last_auto_gesture = stable_gesture
                        print("Message:", " ".join(message_parts))
                elif stable_gesture is None:
                    last_auto_gesture = None

                draw_panel(frame, stable_gesture, message_parts, fps, auto_add, stable_votes)
                cv2.imshow(WINDOW_NAME, frame)

                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break
                if key == 32:
                    if stable_gesture:
                        message_parts.append(GESTURE_MESSAGES[stable_gesture])
                        print("Message:", " ".join(message_parts))
                    else:
                        print("No stable gesture yet. Hold your hand steady and try again.")
                elif key in (ord("a"), ord("A")):
                    auto_add = not auto_add
                    last_auto_gesture = None
                    print("Auto-add:", "ON" if auto_add else "OFF")
                elif key in (ord("c"), ord("C")):
                    message_parts.clear()
                    last_auto_gesture = None
                elif key in (8, 127, 255):
                    if message_parts:
                        message_parts.pop()
                elif key in (ord("s"), ord("S")):
                    speak_text(" ".join(message_parts))

    finally:
        camera.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
