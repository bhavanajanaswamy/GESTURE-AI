# Hackathon Submission Plan — GestureSpeak AI

## One-line description
A privacy-conscious, local-first prototype that turns a small set of generic hand poses into editable text and spoken output.

## Problem statement
Some people may find typing or touch-based interfaces inconvenient in particular situations. GestureSpeak explores whether a simple camera-based interface can offer another way to compose and hear short messages. This prototype is a technical demonstration, not a replacement for established AAC tools or a validated sign-language system.

## What to demonstrate
1. Start the application and show the hand landmarks.
2. Hold an open palm; wait for the stable label.
3. Press SPACE and show “Hello” appended to the message.
4. Add a second pose, then press S to speak the message.
5. Undo with BACKSPACE and clear with C.
6. Toggle auto-add with A and explain its cooldown.
7. End by explaining limitations and the evaluation plan.

## 90-second pitch
Hello judges. Our project is GestureSpeak AI, a local-first gesture-to-speech prototype. We wanted to explore an alternative way to compose short messages using a webcam, particularly for situations where typing may be inconvenient.

OpenCV captures the camera image, and MediaPipe detects 21 hand landmarks. A transparent rule-based classifier maps five generic poses to short phrases. A temporal voting step reduces flickering, while users can confirm phrases manually or use optional auto-add. The completed message can be spoken locally.

Our current version is deliberately limited: these are generic gestures, not sign-language signs, and we do not claim validated accuracy. We have included a repeatable test plan that measures per-class precision and recall, macro-F1, latency, and failure cases. Our next milestone is to evaluate with consent-based, diverse samples and compare the rules against a trained landmark classifier.

Privacy and honest evaluation are part of the design: the app processes camera frames locally and does not upload them. Thank you.

## Judge questions

**What is the AI component?**  
MediaPipe provides pretrained hand-landmark detection. The five-pose classifier in this version is rule-based. A trained classifier is a planned experiment, not a feature we claim is already implemented.

**Is it a sign-language translator?**  
No. It recognizes five generic hand poses and maps them to preset phrases. Sign languages include grammar, movement, facial expression, and context that this prototype does not model.

**How do you measure performance?**  
Use a participant-separated held-out test set. Report per-class precision and recall, macro-F1, a confusion matrix, and latency. Include difficult lighting and hand-orientation cases. Do not report synthetic unit-test performance as real-world accuracy.

**What is novel?**  
The submission combines local processing, temporal stability voting, manual confirmation, optional cooldown-based auto-add, and speech output in a compact demonstrator. Novelty should be supported by comparison with related work and user feedback rather than asserted without evidence.

**What are the risks?**  
False gesture detections could produce the wrong phrase. The small vocabulary and generic mappings limit usefulness. The interface should preserve user confirmation and undo, and must not be relied upon for emergency or essential communication.

**What would you build next?**  
A user-configurable vocabulary, a trained landmark classifier with participant-separated evaluation, calibration, additional languages, a polished accessible interface, and co-design sessions with communication-aid users and accessibility experts.
