# GestureSpeak AI — Hackathon Edition

A local, webcam-based **generic gesture-to-speech prototype** designed to explore accessible communication. It detects a hand with MediaPipe, maps five generic hand poses to short phrases, builds a message, and can read it aloud.

> **Honest scope:** This is not a sign-language translator and should not be presented as one. The current gesture mapping uses geometric rules; MediaPipe provides the pretrained hand-landmark detector. It is a prototype, not a validated assistive medical/communication device.

## What's improved for a hackathon

- More robust webcam initialization and explicit error handling.
- Stability voting over seven recent frames, requiring four matching predictions before showing a gesture.
- Optional **auto-add mode** (`A`) with cooldown to reduce repeated phrase spam.
- A cleaner live status panel with gesture meaning, stability, FPS, and controls.
- Local text-to-speech, message undo, clear, and manual phrase confirmation.
- Expanded documentation, test guidance, evaluation plan, judge Q&A, and demo script.
- Camera frames are processed locally by this application; it does not upload them.

## Current gesture vocabulary

| Generic pose | Output phrase |
|---|---|
| Open palm | Hello |
| Fist | Stop |
| Thumbs-up | Yes |
| Peace sign | Peace |
| Pointing finger | Look there |

These are generic poses and outputs, **not sign-language meanings**. The vocabulary is intentionally small.

## Setup (Windows)

Use 64-bit Python 3.11 for the best chance of dependency compatibility.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation, use Command Prompt:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

## Controls

| Key | Action |
|---|---|
| `SPACE` | Add the currently stable gesture to the message |
| `A` | Toggle auto-add mode |
| `S` | Speak the composed message |
| `BACKSPACE` | Undo the last phrase |
| `C` | Clear the message |
| `Q` or `ESC` | Quit |

## Architecture

1. OpenCV captures a webcam frame and mirrors it for a natural preview.
2. MediaPipe Hands detects 21 landmarks for one hand.
3. `gestures.py` applies transparent geometric heuristics to classify five poses.
4. A short history vote reduces flickering labels.
5. The message builder appends phrases manually or in optional auto-add mode.
6. `pyttsx3` provides local text-to-speech when installed and supported by the OS.

## Testing

Run the unit tests for the rule-based classifier:

```powershell
python -m unittest discover -s tests -v
```

Then run a real-camera smoke test:
- Test all five gestures in bright and dimmer lighting.
- Test with the hand nearer/farther from the camera.
- Test no-hand frames and transitions between gestures.
- Test speech, undo, clear, auto-add, and quit.

Do not claim an accuracy percentage unless it was measured on a held-out test set. The existing unit tests check synthetic landmark patterns; they are not a real-world accuracy benchmark.

## Hackathon evaluation plan

Before presenting, recruit volunteers only with their consent and collect a small, diverse set of examples. Avoid storing identifiable video unless explicitly necessary and consented to.

1. Define the gesture vocabulary and capture protocol before testing.
2. Capture multiple examples per gesture across participants, lighting, distance, and hand orientation.
3. Split data by participant into train/validation/test sets if training a classifier; do not put frames from the same recording in both train and test.
4. Report per-class precision, recall, macro-F1, confusion matrix, end-to-end response time, and failure cases.
5. Compare the current rules against a trained landmark-based classifier before claiming the trained model is better.
6. Ask users whether the interface is understandable and whether phrase confirmation/undo is helpful.

Suggested success targets to validate—not results already achieved:
- At least 90% macro-F1 on a clearly described held-out test set.
- Median recognition-to-message latency under 500 ms on the target laptop.
- Zero duplicate phrases during a 10-second stationary-hold test in auto-add mode.
- Successful task completion by at least 4 of 5 test participants in a short usability test.

## Responsible design and next steps

- Work with sign-language users and accessibility specialists before adding sign-language claims.
- Add user-configurable phrases and language-specific speech options.
- Consider a landmark-based ML classifier trained and evaluated on consent-based examples.
- Add a confidence/uncertain state and a simple calibration step.
- Offer keyboard-only controls and a high-contrast UI.
- Document limitations, test environment, and failure cases in the final submission.

## Project structure

```text
GestureSpeak_AI/
├── app.py
├── gestures.py
├── requirements.txt
├── README.md
├── PRESENTATION_GUIDE.md
├── HACKATHON_PLAN.md
├── LICENSE
└── tests/
    └── test_gestures.py
```

## License

Project code is released under the MIT License. Third-party dependencies and pretrained models have their own licenses; review those terms before redistribution.
